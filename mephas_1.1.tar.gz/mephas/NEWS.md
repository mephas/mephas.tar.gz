
mephas 1.1
==============

* Edited description file
* Changed email
* Combined server and ui functions
* Added validation functions, plot functions
* Added some explanations and interpretations
* Fix bugs 
* Archived in CRAN

mephas 1.0.1
==============

* Edited description file
* Updated server and ui functions
* Removed data information
* Fix bugs  

mephas 1.0.0
============

* Initial release
