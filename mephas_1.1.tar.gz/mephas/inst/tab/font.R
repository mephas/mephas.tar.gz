##----------#----------#----------#----------
##
## Font
##
## Language: EN
## 
## DT: 2019-01-09
##
##----------#----------#----------#----------

tags$style(HTML("*{font-family: Arial, sans-serif;}"))#Helvetica, 
