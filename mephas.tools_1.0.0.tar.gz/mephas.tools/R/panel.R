
## functions for MEPHAS
##
##
##' @title Panel functions for mephas
##'
##' @return panel for upload files used in mephas
##'
##' @examples
##' # NOT Run
##'   
##' @importFrom stats cor reshape
##' @importFrom magrittr %>%
##' @importFrom ROCR prediction performance
##' @importFrom psych describeBy
##' @import ggplot2
##' @import shiny
##'
##' @param file input data
##' @param header input header name
##' @param col input column  name
##' @param sep input separator name
##' @param quote input quote name
##'

##' @export
tabPanel.upload <- function(file ="file", header="header", col="col", sep="sep", quote="quote"){

tabPanel("Upload Data", p(br()),

p(tags$b("Upload data will cover the example data")),
p(("Please refer to the example data format to upload new data")),
#p("We suggested putting the dependent variable (Y) in the left side of all independent variables (X) "),

fileInput(file, "1. Choose CSV/TXT file", accept = c("text/csv","text/comma-separated-values,text/plain",".csv")),

p(tags$b("2. Show 1st row as column names?")), 
#checkboxInput("header", "Yes", TRUE),
shinyWidgets::prettyToggle(
   inputId = header,
   label_on = "Yes", 
    icon_on = icon("check"),
   status_on = "info",
   status_off = "warning", 
    label_off = "No",
   icon_off = icon("remove"),
   value = TRUE
),

p(tags$b("3. Use 1st column as row names? (No duplicates)")), 
#checkboxInput("col", "Yes", TRUE),
shinyWidgets::prettyToggle(
   inputId = col,
   label_on = "Yes", 
    icon_on = icon("check"),
   status_on = "info",
   status_off = "warning", 
    label_off = "No",
   icon_off = icon("remove"),
   value = TRUE
),

shinyWidgets::prettyRadioButtons(
   inputId = sep,
   label = "4. Which separator for data?", 
   status = "info",
   fill = TRUE,
   icon = icon("check"),
  choiceNames = list(
    HTML("Comma (,): CSV often uses this"),
    HTML("One Tab (->|): TXT often uses this"),
    HTML("Semicolon (;)"),
    HTML("One Space (_)")
    ),
  choiceValues = list(",", "\t", ";", " ")
  ),

shinyWidgets::prettyRadioButtons(
   inputId = quote,
   label = "5. Which quote for characters?", 
   status = "info",
   fill = TRUE,
   icon = icon("check"),
  choices = c("None" = "",
           "Double Quote" = '"',
           "Single Quote" = "'"),
  selected = '"'),

p("Correct separator and quote ensure the successful data input"),

a(tags$i("Find some example data here"),href = "https://github.com/mephas/datasets")
  )
}

##' @title panel functions in MEPHAS
##'
##' @return panel for upload files used in mephas
##'
##' @examples
##' # NOT Run
##'
##' @param file input data
##' @param header input header name
##' @param col input column  name
##' @param sep input separator name
##'
##' @export
tabPanel.upload.num <- function(file ="file", header="header", col="col", sep="sep"){

tabPanel("Upload Data", p(br()),

p(tags$b("Upload data will cover the example data")),

fileInput(file, "1. Choose CSV/TXT file", accept = c("text/csv","text/comma-separated-values,text/plain",".csv")),

p(tags$b("2. Show 1st row as column names?")), 
#checkboxInput("header", "Yes", TRUE),
shinyWidgets::prettyToggle(
   inputId = header,
   label_on = "Yes", 
    icon_on = icon("check"),
   status_on = "info",
   status_off = "warning", 
    label_off = "No",
   icon_off = icon("remove"),
   value = TRUE
),

p(tags$b("3. Use 1st column as row names? (No duplicates)")), 
#checkboxInput("col", "Yes", TRUE),
shinyWidgets::prettyToggle(
   inputId = col,
   label_on = "Yes", 
    icon_on = icon("check"),
   status_on = "info",
   status_off = "warning", 
    label_off = "No",
   icon_off = icon("remove"),
   value = TRUE
),

shinyWidgets::prettyRadioButtons(
   inputId = sep,
   label = "4. Which separator for data?", 
   status = "info",
   fill = TRUE,
   icon = icon("check"),
  choiceNames = list(
    HTML("Comma (,): CSV often uses this"),
    HTML("One Tab (->|): TXT often uses this"),
    HTML("Semicolon (;)"),
    HTML("One Space (_)")
    ),
  choiceValues = list(",", "\t", ";", " ")
  ),

p("Correct separator and quote ensure the successful data input"),

a(tags$i("Find some example data here"),href = "https://github.com/mephas/datasets")
  )
}

##' @title panel functions in MEPHAS
##'
##'
##' @return panel for upload files used in mephas
##'
##' @examples
##' # NOT Run
##'
##' @param file input data
##' @param header input header name
##' @param col input column  name
##' @param sep input separator name
##' @param quote input quote name
##'
##' @export
tabPanel.upload.pr <- function(file ="file", header="header", col="col", sep="sep", quote="quote"){

tabPanel("Upload Data", p(br()),

p(tags$b("Data for prediction should cover all the variables in the model")),

#p("We suggested putting the dependent variable (Y) in the left side of all independent variables (X) "),

fileInput(file, "1. Choose CSV/TXT file", accept = c("text/csv","text/comma-separated-values,text/plain",".csv")),

p(tags$b("2. Show 1st row as column names?")), 
#checkboxInput("header", "Yes", TRUE),
shinyWidgets::prettyToggle(
   inputId = header,
   label_on = "Yes", 
    icon_on = icon("check"),
   status_on = "info",
   status_off = "warning", 
    label_off = "No",
   icon_off = icon("remove"),
   value = TRUE
),

p(tags$b("3. Use 1st column as row names? (No duplicates)")), 
#checkboxInput("col", "Yes", TRUE),
shinyWidgets::prettyToggle(
   inputId = col,
   label_on = "Yes", 
    icon_on = icon("check"),
   status_on = "info",
   status_off = "warning", 
    label_off = "No",
   icon_off = icon("remove"),
   value = TRUE
),

shinyWidgets::prettyRadioButtons(
   inputId = sep,
   label = "4. Which separator for data?", 
   status = "info",
   fill = TRUE,
   icon = icon("check"),
  choiceNames = list(
    HTML("Comma (,): CSV often uses this"),
    HTML("One Tab (->|): TXT often uses this"),
    HTML("Semicolon (;)"),
    HTML("One Space (_)")
    ),
  choiceValues = list(",", "\t", ";", " ")
  ),

shinyWidgets::prettyRadioButtons(
   inputId = quote,
   label = "5. Which quote for characters?", 
   status = "info",
   fill = TRUE,
   icon = icon("check"),
  choices = c("None" = "",
           "Double Quote" = '"',
           "Single Quote" = "'"),
  selected = '"'),

p("Correct separator and quote ensure the successful data input"),

a(tags$i("Find some example data here"),href = "https://github.com/mephas/datasets")
  )
}